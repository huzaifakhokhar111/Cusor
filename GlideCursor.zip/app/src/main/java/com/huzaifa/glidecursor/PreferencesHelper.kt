package com.huzaifa.glidecursor

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

class PreferencesHelper(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("glide_cursor_prefs", Context.MODE_PRIVATE)

    var lineColor: Int
        get() = prefs.getInt(KEY_LINE_COLOR, Color.parseColor("#38BDF8")) // Neon Sky Blue
        set(value) = prefs.edit().putInt(KEY_LINE_COLOR, value).apply()

    var maskColor: Int
        get() = prefs.getInt(KEY_MASK_COLOR, Color.parseColor("#121B22")) // WhatsApp Dark default
        set(value) = prefs.edit().putInt(KEY_MASK_COLOR, value).apply()

    var glideDuration: Long
        get() = prefs.getLong(KEY_GLIDE_DURATION, 110L) // 110ms default
        set(value) = prefs.edit().putLong(KEY_GLIDE_DURATION, value).apply()

    var lineWidthDp: Float
        get() = prefs.getFloat(KEY_LINE_WIDTH, 2.5f)
        set(value) = prefs.edit().putFloat(KEY_LINE_WIDTH, value).apply()

    companion object {
        private const val KEY_LINE_COLOR = "line_color"
        private const val KEY_MASK_COLOR = "mask_color"
        private const val KEY_GLIDE_DURATION = "glide_duration"
        private const val KEY_LINE_WIDTH = "line_width"
    }
}
