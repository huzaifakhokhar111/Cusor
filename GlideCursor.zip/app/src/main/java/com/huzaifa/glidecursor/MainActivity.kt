package com.huzaifa.glidecursor

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.appcompat.app.AppCompatActivity
import com.huzaifa.glidecursor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PreferencesHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PreferencesHelper(this)

        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatus()
    }

    private fun updateServiceStatus() {
        val isEnabled = isAccessibilityServiceEnabled()
        if (isEnabled) {
            binding.tvStatus.text = "Service is Active (Gliding Enabled)"
            binding.tvStatus.setTextColor(Color.parseColor("#10B981")) // Green
            binding.btnEnableService.text = "Accessibility Settings"
        } else {
            binding.tvStatus.text = "Service is Inactive"
            binding.tvStatus.setTextColor(Color.parseColor("#F43F5E")) // Red
            binding.btnEnableService.text = "Enable Accessibility Service"
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        for (service in enabledServices) {
            if (service.resolveInfo.serviceInfo.packageName == packageName) {
                return true
            }
        }
        return false
    }

    private fun setupListeners() {
        binding.btnEnableService.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        // Duration Slider
        binding.sliderDuration.value = prefs.glideDuration.toFloat().coerceIn(70f, 200f)
        binding.tvDurationLabel.text = "Duration: ${prefs.glideDuration} ms"

        binding.sliderDuration.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                val duration = value.toLong()
                prefs.glideDuration = duration
                binding.tvDurationLabel.text = "Duration: $duration ms"
                CursorService.reloadPreferences()
            }
        }

        // Line Color Buttons
        binding.btnColorSky.setOnClickListener {
            prefs.lineColor = Color.parseColor("#38BDF8")
            CursorService.reloadPreferences()
        }
        binding.btnColorEmerald.setOnClickListener {
            prefs.lineColor = Color.parseColor("#10B981")
            CursorService.reloadPreferences()
        }
        binding.btnColorPurple.setOnClickListener {
            prefs.lineColor = Color.parseColor("#A855F7")
            CursorService.reloadPreferences()
        }
        binding.btnColorWhite.setOnClickListener {
            prefs.lineColor = Color.parseColor("#FFFFFF")
            CursorService.reloadPreferences()
        }

        // Mask Color Buttons
        binding.btnMaskWhatsApp.setOnClickListener {
            prefs.maskColor = Color.parseColor("#121B22")
            CursorService.reloadPreferences()
        }
        binding.btnMaskBlack.setOnClickListener {
            prefs.maskColor = Color.parseColor("#000000")
            CursorService.reloadPreferences()
        }
        binding.btnMaskWhite.setOnClickListener {
            prefs.maskColor = Color.parseColor("#FFFFFF")
            CursorService.reloadPreferences()
        }
    }
}
