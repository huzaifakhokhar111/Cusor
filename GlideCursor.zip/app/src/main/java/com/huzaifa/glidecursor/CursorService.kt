package com.huzaifa.glidecursor

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.graphics.RectF
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class CursorService : AccessibilityService() {

    private var overlay: CursorOverlay? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        overlay = CursorOverlay(this).apply {
            attachToWindow()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || overlay == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                handleCursorUpdate(event)
            }
        }
    }

    private fun handleCursorUpdate(event: AccessibilityEvent) {
        val node = event.source ?: return
        try {
            if (!node.isEditable && !node.className.toString().contains("EditText", ignoreCase = true)) {
                overlay?.hideCursor()
                return
            }

            val text = node.text?.toString() ?: ""
            // Cursor position in text
            val cursorIndex = if (event.toIndex >= 0) {
                event.toIndex
            } else {
                node.textSelectionEnd
            }

            val nodeBounds = Rect()
            node.getBoundsInScreen(nodeBounds)

            // When field is empty or caret is at start
            if (cursorIndex <= 0 || text.isEmpty()) {
                val density = resources.displayMetrics.density
                val left = nodeBounds.left.toFloat() + (8f * density)
                val top = nodeBounds.top.toFloat() + (6f * density)
                val bottom = nodeBounds.bottom.toFloat() - (6f * density)
                overlay?.updatePosition(left, top, bottom)
                return
            }

            // Query character bounds from AccessibilityNodeInfo
            val charIndex = (cursorIndex - 1).coerceIn(0, text.length - 1)
            val args = Bundle().apply {
                putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX, charIndex)
                putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH, 1)
            }

            val refreshed = node.refreshWithExtraData(
                AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY,
                args
            )

            if (refreshed) {
                val extras = node.extras
                val data = extras?.getParcelableArray(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY)
                if (data != null && data.isNotEmpty()) {
                    val rectF = data[0] as? RectF
                    if (rectF != null && rectF.right > 0) {
                        overlay?.updatePosition(rectF.right, rectF.top, rectF.bottom)
                        return
                    }
                }
            }

            // Fallback estimation using node bounds if character location is unavailable
            val approxTop = nodeBounds.top.toFloat() + (6f * resources.displayMetrics.density)
            val approxBottom = nodeBounds.bottom.toFloat() - (6f * resources.displayMetrics.density)
            val approxX = nodeBounds.left.toFloat() + (12f * resources.displayMetrics.density)
            overlay?.updatePosition(approxX, approxTop, approxBottom)

        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            node.recycle()
        }
    }

    override fun onInterrupt() {
        overlay?.hideCursor()
    }

    override fun onDestroy() {
        overlay?.detachFromWindow()
        overlay = null
        instance = null
        super.onDestroy()
    }

    companion object {
        var instance: CursorService? = null
            private set

        fun reloadPreferences() {
            instance?.overlay?.reloadPreferences()
        }
    }
}
